# FORGE Workout Dashboard Pro

Upload these files to your GitHub Pages repo:

- index.html
- manifest.webmanifest
- sw.js
- icon-192.png
- icon-512.png

This is the best regular web version. It does not use Apple Health and does not require Xcode.

## New features

- Start Workout mode
- Auto next move / progression suggestions
- Weekly coach recap
- Body tracker
- Exercise swap selector
- PWA install support
- Offline cache through service worker
- Backup and restore support from the previous version
